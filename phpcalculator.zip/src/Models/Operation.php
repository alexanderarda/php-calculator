<?php


namespace Jakmall\Recruitment\Calculator\Models;


class Operation
{

    protected $name;
    protected $symbol;
    protected $arguments;
    protected $total = 0;
    protected $timestamp;

    public function __construct(

        $symbol, $name, $arguments

    ) {
        $this->symbol = $symbol;
        $this->name = $name;
        $this->arguments = $arguments;
        $this->timestamp = date('Y-m-d h:i:s');
    }

    public function getArguments()
    {
        return $this->arguments;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getTotal()
    {
        return $this->total;
    }

    public function setTotal($total)
    {
        return $this->total = $total;
    }

    public function getTimeStamp()
    {
        return $this->timestamp;
    }

    public function getDescription()
    {
        return implode($this->arguments, " $this->symbol ");
    }

    public function getResult()
    {
        return(sprintf("%s = %s", $this->getDescription(), $this->total));
    }
}

<?php


namespace Jakmall\Recruitment\Calculator\Drivers;


use Jakmall\Recruitment\Calculator\Models\Operation as Model;

class Database implements DriverInterface
{

    public function list()
    {
        // TODO: Implement list() method.
    }

    public function append(Model $model)
    {
        // TODO: Implement append() method.
    }

    public function delete()
    {
        // TODO: Implement delete() method.
    }
}
